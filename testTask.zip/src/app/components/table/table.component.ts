import {Component, Input, OnInit} from '@angular/core';
import {User} from "../../models/user";

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  @Input() userList: User[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  sortBy(keyName: string): void{
    // @ts-ignore
    this.userList = this.userList.sort((a, b) => (a[keyName] > b[keyName] ? 1 : -1))
  }

  sortByDown(keyName: string): void {
    // @ts-ignore
    this.userList = this.userList.sort((a, b) => (a[keyName] < b[keyName] ? 1 : -1))
  }
}
